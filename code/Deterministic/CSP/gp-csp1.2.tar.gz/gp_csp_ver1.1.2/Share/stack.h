
/*
 *  Stack routines available.
 */
void  create_stack();
void  destroy_stack();
int   stack_empty();
void  push();
int   pop();

