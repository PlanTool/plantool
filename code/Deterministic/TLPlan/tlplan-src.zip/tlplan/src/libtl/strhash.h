int StrHashSearchInsert(char *,char **result, int *position);
int StrHashCreate();
void StrHashClear();
void MarkStrHash();
int StrHashGetCount();
int StrHashGetCollisions();
int StrHashGetTableSize();

void StrHashDump();

