// interface defination for module mybug, Sat Oct 23 12:24:43 2004
#ifndef CLAIREH_mybug
#define CLAIREH_mybug



// namespace class for mybug 
class mybugClass: public NameSpace {
public:


// module definition 
 void metaLoad();};

extern mybugClass mybug;

#endif
