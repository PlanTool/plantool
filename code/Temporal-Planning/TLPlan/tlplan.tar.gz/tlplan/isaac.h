/* isaac.h */

/* global function definitions */

unsigned int IsaacRand(void);
void IsaacSeed(unsigned int);


