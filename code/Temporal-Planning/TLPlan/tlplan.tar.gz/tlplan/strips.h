#ifndef __STRIPS_H
#define __STRIPS_H

/* strips.h */

BOOL EvalDefStripsOperator
(
	CELLP pcFormula,
	LINEARPLANP plpLinearPlan,
	BINDINGP pbBindings
);

#endif /* __STRIPS_H */
