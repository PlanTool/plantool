/* userlib.h */

/* global data */

extern HINSTANCE hInstance;				/* Global instance handle for DLL */
