#include "BeliefValuePair.h"

BeliefValuePair::BeliefValuePair(void)
{
	disabled = false;
	version = 0;
}

BeliefValuePair::~BeliefValuePair(void)
{
}
