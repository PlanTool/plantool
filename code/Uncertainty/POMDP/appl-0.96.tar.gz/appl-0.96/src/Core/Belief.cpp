//#include "Belief.h"
//
//Belief::Belief(void)
//{
//}
//
//Belief::~Belief(void)
//{
//}
