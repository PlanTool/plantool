#ifndef Belief_H
#define Belief_H

#include "SparseVector.h"
using namespace momdp;
namespace momdp 
{
	typedef SparseVector Belief;
	//class Belief : public MObject
	//{
	//public:
	//	Belief(void);
	//	virtual ~Belief(void) = 0;
	//};
}

#endif

