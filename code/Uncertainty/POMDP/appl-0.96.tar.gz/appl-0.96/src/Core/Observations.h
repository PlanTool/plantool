#ifndef Observations_H
#define Observations_H

#include <string>
#include "SymbolSet.h"
#include "IVariableValue.h"
#include "IVariable.h"
#include "VariableContainer.h"

#define Observations VariableContainer 
#define Observation ValueSet 

#endif

