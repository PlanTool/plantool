#pragma once

class Policy
{
public:

	Policy(void)
	{
	}

	virtual ~Policy(void)
	{
	}
};
