#include "IVariable.h"

using namespace momdp;
IVariable::IVariable(void)
{
}

IVariable::~IVariable(void)
{
}
