#include "IVariableValue.h"

using namespace momdp;
IVariableValue::IVariableValue(void)
{
}

IVariableValue::~IVariableValue(void)
{
}
