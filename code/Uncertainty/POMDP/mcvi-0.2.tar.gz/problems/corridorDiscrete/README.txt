In this problem, there are 4 doors. The robot starts at the first door
from the right and wants to open the second door from the left.

The movement is noisy but the observation is perfect. The robot may
move in the correct direction 99% of the time, and 1% in the opposite
direction. The observations are Nothing, Left End, Right End, Wrong
door (if it opens a wrong door).

The reward for opening the correct door is 10, and the wrong door is
-2. Movement cost is -0.5. Discount factor is 0.95.

