There are 4 doors on a continuous corridor. The robot needs to get to
the third door from the left and open it.  The robot does not know its
exact location, but can gather information from 4 observations:
Left-End, Right-End, Door,and Corridor

This is the problem in the paper
   1/ "Point-based value iteration for continuous
   POMDPs" (Porta et al, J. Machine Learning Research, 2006)

   2/"Monte Carlo Value Iteration for Continuous-State POMDPs"
   (Bai et al, WAFR 2011)
