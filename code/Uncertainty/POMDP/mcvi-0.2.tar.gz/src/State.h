#ifndef __STATE_H
#define __STATE_H

#include <vector>

typedef std::vector<double> State; // shorthand for defining state

#endif
