import gpcsp
argv = ['gpcsp', '-o', 'domain.pddl', '-f', 'problem.pddl']
gpcsp.run(argv)