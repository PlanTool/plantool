
import ipp

problem = 'prob01.pddl'

fact = 'domain01.pddl'

ipp.run(['ipp', '-f', problem, '-o', fact, '-r', 'output88'])
