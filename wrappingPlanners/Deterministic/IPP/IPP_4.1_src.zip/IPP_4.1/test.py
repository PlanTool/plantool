
import ipp

fact = 'prob01.pddl'

problem = 'domain01.pddl'

ipp.run(['ipp', '-o', problem, '-f', fact])
