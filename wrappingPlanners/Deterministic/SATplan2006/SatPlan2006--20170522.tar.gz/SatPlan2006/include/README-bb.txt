All changes made to bb were with Action-Based Encoding in mind.  All other encoding schemes were not kept up to date as bb evolved to
support satplan.

Pruning solutions, sorting solutions, etc. are still in main.c simply because all of the information is available for such things there.
