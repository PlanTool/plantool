/*
* $Revision: 1.3 $
* $Date: 1999/06/16 13:31:10 $
*/

#ifndef __TIMINTERFACE
#define __TIMINTERFACE

#include "States.h"
#include "Rules.h"


void initialiseTIM();
void stan(ostream &);
void timcall();

#endif
