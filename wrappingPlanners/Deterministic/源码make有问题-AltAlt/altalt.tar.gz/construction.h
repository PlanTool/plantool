/* 
* $Revision: 3.1 $
* $Date: 1999/01/06 10:15:43 $


construction.h */

#ifndef __CONSTRUCTION
#define __CONSTRUCTION

#include "facts.h"

void build_layer(int);
int build_initial_segment(token_list,token_list);
int all_possible(int,token_list);

#endif
