/* 
* $Revision: 3.2 $
* $Date: 1999/05/03 19:28:15 $


switches.h -- All the main global definitions and stuff. */

/* STAN compilation switches: */

//#define STANSHOW
//#define STANSHOW1
//#define SYMSHOW
#define SYMMETRY
//#define SYMMETRYCONTEXT
//#define SYMMETRYOUT
//#define TECHSYMMETRYOUT
//#define TIMOUT
//#define GUI
