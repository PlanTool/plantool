#!/bin/bash

grep $1 *.lisp */*.lisp */*/*.lisp */*/*/*.lisp *.asd */*/*.asd

